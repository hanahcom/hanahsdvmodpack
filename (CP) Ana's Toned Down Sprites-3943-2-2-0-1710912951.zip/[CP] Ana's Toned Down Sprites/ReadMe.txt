[CP] Ana's Toned Down Sprites - 2.2.0


Toned down versions of all of the vanilla sprites to match some map recolors better.
Works well with A Toned Down Stardew Valley, Eemie's Map Recolors, and Earthy Recolour.

Matching portraits can be found here: https://www.nexusmods.com/stardewvalley/mods/3939/

FEATURES:
- Saturation of each sprite brought down by 40%

REQUIREMENTS:
- SMAPI (https://smapi.io)
- Content Patcher (https://www.nexusmods.com/stardewvalley/mods/1915)

TO INSTALL:
- Install latest version of SMAPI
- Install Content Patcher
- Download and unzip into Stardew Valley/Mods
- Run the game with SMAPI to generate config.json
- Use config.json to enable/disable any sprites
- OPTIONAL: Install Generic Mod Config Menu to configure while in game (https://www.nexusmods.com/stardewvalley/mods/5098)

UNINSTALL:
- Remove from Stardew Valley/Mods

CONFIG:
- "true" to enable the character's sprite
- "false" to disable the character's sprite (use this if you're already using an NPC overhaul mod such as wizard, krobus, or linus replacements)
- Defaults to true

CREDIT:
- https://twitter.com/anatxse
- https://www.nexusmods.com/users/69122888

Please do not reupload, redistribute, or edit without permission!