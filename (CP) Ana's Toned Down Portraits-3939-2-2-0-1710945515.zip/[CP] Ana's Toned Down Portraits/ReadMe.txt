[CP] Ana's Toned Down Portraits - 2.2.0


Toned down versions of all of the vanilla portraits to match some map recolors better.
Works well with A Toned Down Stardew Valley, Eemie's Map Recolors, and DaisyNiko's Earthy Recolour.

Matching sprites can be found here: https://www.nexusmods.com/stardewvalley/mods/3943/

FEATURES:
- Saturation of each portrait brought down by 40%
- New in 1.6: Portraits for new NPCs

REQUIREMENTS:
- SMAPI (https://smapi.io)
- Content Patcher (https://www.nexusmods.com/stardewvalley/mods/1915)

TO INSTALL:
- Install latest version of SMAPI
- Install Content Patcher
- Download and unzip into Stardew Valley/Mods
- Run the game with SMAPI to generate config.json
- Use config.json to enable/disable any sprites
- OPTIONAL: Install Generic Mod Config Menu to configure while in game (https://www.nexusmods.com/stardewvalley/mods/5098)

UNINSTALL:
- Remove from Stardew Valley/Mods

CONFIG:
- "true" to enable the character's portrait
- "false" to disable the character's portrait (use this if you're already using an NPC overhaul mod such as wizard, krobus, or linus replacements)
- Defaults to true

CREDIT:
- https://x.com/anatxse
- https://www.nexusmods.com/users/69122888

Please do not reupload, redistribute, or edit without permission!